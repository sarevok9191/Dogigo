import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/components/custom_sheets/register_done_sheet/register_done_sheet_widget.dart';
import '/components/global/loading_view/loading_view_widget.dart';
import '/components/inputs/date_input_wrapper/date_input_wrapper_widget.dart';
import '/components/inputs/email_wrapper/email_wrapper_widget.dart';
import '/components/inputs/password_input_wrapper/password_input_wrapper_widget.dart';
import '/components/inputs/phone_input_wrapper/phone_input_wrapper_widget.dart';
import '/components/inputs/select_dropdown/select_dropdown_widget.dart';
import '/components/inputs/text_area_wrapper/text_area_wrapper_widget.dart';
import '/components/inputs/text_input_wrapper/text_input_wrapper_widget.dart';
import '/components/modals/web_view_modal/web_view_modal_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'register_screen_model.dart';
export 'register_screen_model.dart';

class RegisterScreenWidget extends StatefulWidget {
  const RegisterScreenWidget({super.key});

  static String routeName = 'RegisterScreen';
  static String routePath = 'registerScreen';

  @override
  State<RegisterScreenWidget> createState() => _RegisterScreenWidgetState();
}

class _RegisterScreenWidgetState extends State<RegisterScreenWidget> {
  late RegisterScreenModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => RegisterScreenModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.loading = true;
      safeSetState(() {});
      _model.apiResult6vy = await StaticValuesGroup.getCountriesCall.call();

      if ((_model.apiResult6vy?.succeeded ?? true)) {
        _model.countries = (getJsonField(
          (_model.apiResult6vy?.jsonBody ?? ''),
          r'''$.records''',
          true,
        )!
                .toList()
                .map<SelectableOptionTypeStruct?>(
                    SelectableOptionTypeStruct.maybeFromMap)
                .toList() as Iterable<SelectableOptionTypeStruct?>)
            .withoutNulls
            .toList()
            .cast<SelectableOptionTypeStruct>();
      }
      _model.apiResultpsi = await StaticValuesGroup.getDogTypesCall.call();

      if ((_model.apiResultpsi?.succeeded ?? true)) {
        FFAppState().DogTypes = (getJsonField(
          (_model.apiResultpsi?.jsonBody ?? ''),
          r'''$.records''',
          true,
        )!
                .toList()
                .map<SelectableOptionTypeStruct?>(
                    SelectableOptionTypeStruct.maybeFromMap)
                .toList() as Iterable<SelectableOptionTypeStruct?>)
            .withoutNulls
            .toList()
            .cast<SelectableOptionTypeStruct>();
      }
      _model.apiResultxdo = await StaticValuesGroup.getGendersCall.call();

      if ((_model.apiResultxdo?.succeeded ?? true)) {
        _model.genders = (getJsonField(
          (_model.apiResultxdo?.jsonBody ?? ''),
          r'''$.records''',
          true,
        )!
                .toList()
                .map<SelectableOptionTypeStruct?>(
                    SelectableOptionTypeStruct.maybeFromMap)
                .toList() as Iterable<SelectableOptionTypeStruct?>)
            .withoutNulls
            .toList()
            .cast<SelectableOptionTypeStruct>();
        FFAppState().Genders = (getJsonField(
          (_model.apiResultxdo?.jsonBody ?? ''),
          r'''$.records''',
          true,
        )!
                .toList()
                .map<SelectableOptionTypeStruct?>(
                    SelectableOptionTypeStruct.maybeFromMap)
                .toList() as Iterable<SelectableOptionTypeStruct?>)
            .withoutNulls
            .toList()
            .cast<SelectableOptionTypeStruct>();
      }
      _model.loading = false;
      safeSetState(() {});
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Container(
          height: double.infinity,
          child: Stack(
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, -1.0),
                child: Container(
                  width: MediaQuery.sizeOf(context).width * 1.0,
                  height: 400.0,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      alignment: AlignmentDirectional(0.0, 0.0),
                      image: Image.asset(
                        'assets/images/login-top-bg.png',
                      ).image,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 48.0, 0.0, 0.0),
                  child: Container(
                    width: MediaQuery.sizeOf(context).width * 1.0,
                    height: MediaQuery.sizeOf(context).height * 1.0,
                    decoration: BoxDecoration(),
                    alignment: AlignmentDirectional(0.0, -1.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(32.0, 12.0, 32.0, 0.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Stack(
                            alignment: AlignmentDirectional(0.0, -1.0),
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8.0),
                                child: SvgPicture.asset(
                                  'assets/images/login-logo.svg',
                                  width: 96.0,
                                  height: 48.0,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Align(
                                alignment: AlignmentDirectional(-1.0, 0.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    if (_model.pageViewCurrentIndex == 0) {
                                      context.safePop();
                                    } else {
                                      await _model.pageViewController
                                          ?.previousPage(
                                        duration: Duration(milliseconds: 300),
                                        curve: Curves.ease,
                                      );
                                    }
                                  },
                                  child: Container(
                                    width: 49.0,
                                    height: 49.0,
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      borderRadius: BorderRadius.circular(14.0),
                                      border: Border.all(
                                        color: FlutterFlowTheme.of(context)
                                            .secondary,
                                      ),
                                    ),
                                    child: Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Icon(
                                        Icons.arrow_back_ios_new_sharp,
                                        color: FlutterFlowTheme.of(context)
                                            .secondary,
                                        size: 24.0,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 24.0, 0.0, 0.0),
                            child: Text(
                              FFLocalizations.of(context).getText(
                                'bb62k52v' /* Hesap Oluştur */,
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    font: GoogleFonts.manrope(
                                      fontWeight: FontWeight.w600,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                                    color: FlutterFlowTheme.of(context).primary,
                                    fontSize: 25.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                            ),
                          ),
                          Expanded(
                            child: Stack(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height:
                                      MediaQuery.sizeOf(context).height * 1.0,
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 24.0, 0.0, 0.0),
                                    child: PageView(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      controller: _model.pageViewController ??=
                                          PageController(initialPage: 0),
                                      onPageChanged: (_) => safeSetState(() {}),
                                      scrollDirection: Axis.horizontal,
                                      children: [
                                        Form(
                                          key: _model.formKey2,
                                          autovalidateMode:
                                              AutovalidateMode.disabled,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Align(
                                                  alignment:
                                                      AlignmentDirectional(
                                                          0.0, 0.0),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                41.0,
                                                                32.0,
                                                                41.0,
                                                                10.0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              SvgPicture.asset(
                                                            'assets/images/register-dog-icon.svg',
                                                            width: 26.0,
                                                            height: 38.0,
                                                            fit: BoxFit.cover,
                                                          ),
                                                        ),
                                                        Flexible(
                                                          child: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'i7wkq3ob' /* Hey, köpek dostu!  Lütfen hakk... */,
                                                            ),
                                                            textAlign:
                                                                TextAlign.start,
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font: GoogleFonts
                                                                      .manrope(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primary,
                                                                  fontSize:
                                                                      13.0,
                                                                  letterSpacing:
                                                                      0.2,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                      ].divide(SizedBox(
                                                          width: 12.0)),
                                                    ),
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model.nameInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: TextInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'İsim',
                                                      enText: 'Name',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: true,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model:
                                                      _model.surnameInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: TextInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Soyisim',
                                                      enText: 'Surname',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model.phoneInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child:
                                                      PhoneInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Telefon Numarası',
                                                      enText: 'Phone Number',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model:
                                                      _model.emailWrapperModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: EmailWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      '65s7t44h' /* E-posta */,
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .usernameWrapperModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: EmailWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Kullanıcı Adı',
                                                      enText: 'Username',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model:
                                                      _model.passwordInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child:
                                                      PasswordInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Şifre',
                                                      enText: 'Password',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .repeatPasswordInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child:
                                                      PasswordInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Şifre Tekrarı',
                                                      enText: 'Repeat Password',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .birthdateInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: DateInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Doğum Tarihi',
                                                      enText: 'Birth Date',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                    initialValue: '',
                                                    maxDate: null,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .genderSelectDropdownModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: SelectDropdownWidget(
                                                    labelTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Cinsiyet',
                                                      enText: 'Sex',
                                                    ),
                                                    dropdownTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Cinsiyetinizi Seçin',
                                                      enText: 'Select Your Sex',
                                                    ),
                                                    options:
                                                        FFAppState().Genders,
                                                    sheetTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Cinsiyetinizi Seçin',
                                                      enText: 'Select Your Sex',
                                                    ),
                                                    absorbing: false,
                                                    isRequired: true,
                                                    onValueChange:
                                                        (value) async {},
                                                  ),
                                                ),
                                                FutureBuilder<ApiCallResponse>(
                                                  future: _model.countriesList(
                                                    requestFn: () =>
                                                        StaticValuesGroup
                                                            .getCountriesCall
                                                            .call(),
                                                  ),
                                                  builder: (context, snapshot) {
                                                    // Customize what your widget looks like when it's loading.
                                                    if (!snapshot.hasData) {
                                                      return Center(
                                                        child: SizedBox(
                                                          width: 20.0,
                                                          height: 20.0,
                                                          child:
                                                              SpinKitPumpingHeart(
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primary,
                                                            size: 20.0,
                                                          ),
                                                        ),
                                                      );
                                                    }
                                                    final countrySelectDropdownGetCountriesResponse =
                                                        snapshot.data!;

                                                    return wrapWithModel(
                                                      model: _model
                                                          .countrySelectDropdownModel,
                                                      updateCallback: () =>
                                                          safeSetState(() {}),
                                                      child:
                                                          SelectDropdownWidget(
                                                        labelTitle:
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getVariableText(
                                                          trText: 'Ülke',
                                                          enText: 'Country',
                                                        ),
                                                        dropdownTitle:
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getVariableText(
                                                          trText: 'Ülke Seçin',
                                                          enText:
                                                              'Select Country',
                                                        ),
                                                        options:
                                                            _model.countries,
                                                        sheetTitle:
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getVariableText(
                                                          trText: 'Ülke Seçin',
                                                          enText:
                                                              'Select Country',
                                                        ),
                                                        absorbing: false,
                                                        isRequired: true,
                                                        onValueChange:
                                                            (value) async {
                                                          _model.citiesRepsonse =
                                                              await StaticValuesGroup
                                                                  .getCitiesCall
                                                                  .call(
                                                            countryId:
                                                                value?.id,
                                                          );

                                                          if ((_model
                                                                  .citiesRepsonse
                                                                  ?.succeeded ??
                                                              true)) {
                                                            _model
                                                                .cities = (getJsonField(
                                                              (_model.citiesRepsonse
                                                                      ?.jsonBody ??
                                                                  ''),
                                                              r'''$.records''',
                                                              true,
                                                            )!
                                                                    .toList()
                                                                    .map<SelectableOptionTypeStruct?>(SelectableOptionTypeStruct.maybeFromMap)
                                                                    .toList() as Iterable<SelectableOptionTypeStruct?>)
                                                                .withoutNulls
                                                                .toList()
                                                                .cast<SelectableOptionTypeStruct>();
                                                            safeSetState(() {});
                                                          }

                                                          safeSetState(() {});
                                                        },
                                                      ),
                                                    );
                                                  },
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .citySelectDropdownModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: SelectDropdownWidget(
                                                    labelTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Şehir',
                                                      enText: 'City',
                                                    ),
                                                    dropdownTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Şehir Seçin',
                                                      enText: 'Select City',
                                                    ),
                                                    options: _model.cities,
                                                    sheetTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Şehir Seçin',
                                                      enText: 'Select City',
                                                    ),
                                                    absorbing: _model
                                                            .countrySelectDropdownModel
                                                            .value ==
                                                        null,
                                                    isRequired: true,
                                                    onValueChange:
                                                        (value) async {},
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model:
                                                      _model.addressInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: TextAreaWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Adres',
                                                      enText: 'Address',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                Material(
                                                  color: Colors.transparent,
                                                  child: Theme(
                                                    data: ThemeData(
                                                      checkboxTheme:
                                                          CheckboxThemeData(
                                                        visualDensity:
                                                            VisualDensity
                                                                .compact,
                                                        materialTapTargetSize:
                                                            MaterialTapTargetSize
                                                                .shrinkWrap,
                                                      ),
                                                      unselectedWidgetColor:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .alternate,
                                                    ),
                                                    child: CheckboxListTile(
                                                      value: _model
                                                              .checkboxListTileValue ??=
                                                          false,
                                                      onChanged:
                                                          (newValue) async {
                                                        safeSetState(() => _model
                                                                .checkboxListTileValue =
                                                            newValue!);
                                                        if (newValue!) {
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return WebViewAware(
                                                                child:
                                                                    GestureDetector(
                                                                  onTap: () {
                                                                    FocusScope.of(
                                                                            context)
                                                                        .unfocus();
                                                                    FocusManager
                                                                        .instance
                                                                        .primaryFocus
                                                                        ?.unfocus();
                                                                  },
                                                                  child:
                                                                      Padding(
                                                                    padding: MediaQuery
                                                                        .viewInsetsOf(
                                                                            context),
                                                                    child:
                                                                        Container(
                                                                      height:
                                                                          MediaQuery.sizeOf(context).height *
                                                                              0.8,
                                                                      child:
                                                                          WebViewModalWidget(),
                                                                    ),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));
                                                        }
                                                      },
                                                      title: Text(
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                          'wsm9wjt2' /* Kullanıcı Gizlilik Sözleşmesi */,
                                                        ),
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleLarge
                                                                .override(
                                                                  font: GoogleFonts
                                                                      .manrope(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleLarge
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleLarge
                                                                        .fontStyle,
                                                                  ),
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primary,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleLarge
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleLarge
                                                                      .fontStyle,
                                                                ),
                                                      ),
                                                      subtitle: Text(
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                          'snp44xyp' /* Kayıt olmak için kabul etmeniz... */,
                                                        ),
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelMedium
                                                                .override(
                                                                  font: GoogleFonts
                                                                      .manrope(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .labelMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .labelMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondary,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .labelMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .labelMedium
                                                                      .fontStyle,
                                                                ),
                                                      ),
                                                      activeColor:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .primary,
                                                      checkColor:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .info,
                                                      dense: false,
                                                      controlAffinity:
                                                          ListTileControlAffinity
                                                              .trailing,
                                                      contentPadding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  12.0,
                                                                  0.0,
                                                                  12.0,
                                                                  0.0),
                                                      shape:
                                                          RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 26.0, 0.0, 0.0),
                                                  child: FFButtonWidget(
                                                    onPressed: () async {
                                                      if (_model
                                                              .checkboxListTileValue ==
                                                          false) {
                                                        ScaffoldMessenger.of(
                                                                context)
                                                            .showSnackBar(
                                                          SnackBar(
                                                            content: Text(
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .getVariableText(
                                                                trText:
                                                                    'Kullanıcı Sözleşmesini Kabul Etmeniz Gerekmektedir.',
                                                                enText:
                                                                    'You do not need to accept the User Agreement.',
                                                              ),
                                                              style: TextStyle(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .primaryText,
                                                              ),
                                                            ),
                                                            duration: Duration(
                                                                milliseconds:
                                                                    4000),
                                                            backgroundColor:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondary,
                                                          ),
                                                        );
                                                      } else {
                                                        if ((_model.birthdateInputModel.value == null) ||
                                                            (_model
                                                                        .nameInputModel
                                                                        .customInputTextController
                                                                        .text ==
                                                                    '') ||
                                                            (_model
                                                                        .surnameInputModel
                                                                        .customInputTextController
                                                                        .text ==
                                                                    '') ||
                                                            (_model
                                                                        .phoneInputModel
                                                                        .customInputTextController
                                                                        .text ==
                                                                    '') ||
                                                            (_model
                                                                        .emailWrapperModel
                                                                        .customInputTextController
                                                                        .text ==
                                                                    '') ||
                                                            (_model
                                                                        .usernameWrapperModel
                                                                        .customInputTextController
                                                                        .text ==
                                                                    '') ||
                                                            (_model
                                                                        .passwordInputModel
                                                                        .customInputTextController
                                                                        .text ==
                                                                    '') ||
                                                            (_model
                                                                        .repeatPasswordInputModel
                                                                        .customInputTextController
                                                                        .text ==
                                                                    '')) {
                                                          ScaffoldMessenger.of(
                                                                  context)
                                                              .showSnackBar(
                                                            SnackBar(
                                                              content: Text(
                                                                FFLocalizations.of(
                                                                        context)
                                                                    .getVariableText(
                                                                  trText:
                                                                      'Lütfen zorunlu alanları doldurunuz.',
                                                                  enText:
                                                                      'Please fill the required fields',
                                                                ),
                                                                style:
                                                                    TextStyle(
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .info,
                                                                ),
                                                              ),
                                                              duration: Duration(
                                                                  milliseconds:
                                                                      4000),
                                                              backgroundColor:
                                                                  FlutterFlowTheme.of(
                                                                          context)
                                                                      .primary,
                                                            ),
                                                          );
                                                        } else {
                                                          if (_model
                                                                  .birthdateInputModel
                                                                  .value! >=
                                                              getCurrentTimestamp) {
                                                            ScaffoldMessenger
                                                                    .of(context)
                                                                .showSnackBar(
                                                              SnackBar(
                                                                content: Text(
                                                                  FFLocalizations.of(
                                                                          context)
                                                                      .getVariableText(
                                                                    trText:
                                                                        'Lütfen zorunlu alanları doldurunuz.',
                                                                    enText:
                                                                        'Please fill the required fields',
                                                                  ),
                                                                  style:
                                                                      TextStyle(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .info,
                                                                  ),
                                                                ),
                                                                duration: Duration(
                                                                    milliseconds:
                                                                        4000),
                                                                backgroundColor:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .primary,
                                                              ),
                                                            );
                                                          } else {
                                                            _model.checkRegisterResponse =
                                                                await AuthenticationGroup
                                                                    .checkRegisterUniqueCall
                                                                    .call(
                                                              email: _model
                                                                  .emailWrapperModel
                                                                  .customInputTextController
                                                                  .text,
                                                              username: _model
                                                                  .usernameWrapperModel
                                                                  .customInputTextController
                                                                  .text,
                                                              dateBirth: _model
                                                                  .birthdateInputModel
                                                                  .value
                                                                  ?.toString(),
                                                              password: _model
                                                                  .passwordInputModel
                                                                  .customInputTextController
                                                                  .text,
                                                              passwordConfirmation: _model
                                                                  .repeatPasswordInputModel
                                                                  .customInputTextController
                                                                  .text,
                                                            );

                                                            if ((_model
                                                                    .checkRegisterResponse
                                                                    ?.succeeded ??
                                                                true)) {
                                                              if (_model.formKey2
                                                                          .currentState ==
                                                                      null ||
                                                                  !_model
                                                                      .formKey2
                                                                      .currentState!
                                                                      .validate()) {
                                                                return;
                                                              }
                                                              if (_model
                                                                      .passwordInputModel
                                                                      .customInputTextController
                                                                      .text ==
                                                                  _model
                                                                      .repeatPasswordInputModel
                                                                      .customInputTextController
                                                                      .text) {
                                                                await _model
                                                                    .pageViewController
                                                                    ?.nextPage(
                                                                  duration: Duration(
                                                                      milliseconds:
                                                                          300),
                                                                  curve: Curves
                                                                      .ease,
                                                                );
                                                              } else {
                                                                ScaffoldMessenger.of(
                                                                        context)
                                                                    .showSnackBar(
                                                                  SnackBar(
                                                                    content:
                                                                        Text(
                                                                      FFLocalizations.of(
                                                                              context)
                                                                          .getVariableText(
                                                                        trText:
                                                                            'Şifre tekrarı eşleşmiyor',
                                                                        enText:
                                                                            'Password Confirmation Doesnt Match',
                                                                      ),
                                                                      style:
                                                                          TextStyle(
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .info,
                                                                      ),
                                                                    ),
                                                                    duration: Duration(
                                                                        milliseconds:
                                                                            4000),
                                                                    backgroundColor:
                                                                        FlutterFlowTheme.of(context)
                                                                            .primary,
                                                                  ),
                                                                );
                                                              }
                                                            } else {
                                                              if ((_model.checkRegisterResponse
                                                                          ?.statusCode ??
                                                                      200) ==
                                                                  422) {
                                                                ScaffoldMessenger.of(
                                                                        context)
                                                                    .showSnackBar(
                                                                  SnackBar(
                                                                    content:
                                                                        Text(
                                                                      functions.getValidationErrorMessages((_model
                                                                              .checkRegisterResponse
                                                                              ?.jsonBody ??
                                                                          '')),
                                                                      style:
                                                                          TextStyle(
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .info,
                                                                      ),
                                                                    ),
                                                                    duration: Duration(
                                                                        milliseconds:
                                                                            4000),
                                                                    backgroundColor:
                                                                        FlutterFlowTheme.of(context)
                                                                            .primary,
                                                                  ),
                                                                );
                                                              } else {
                                                                ScaffoldMessenger.of(
                                                                        context)
                                                                    .showSnackBar(
                                                                  SnackBar(
                                                                    content:
                                                                        Text(
                                                                      FFLocalizations.of(
                                                                              context)
                                                                          .getVariableText(
                                                                        trText:
                                                                            'Bir Hata Oluştu! Lütfen daha sonra tekrar deneyin',
                                                                        enText:
                                                                            'An Error Occurred! Please try again later.',
                                                                      ),
                                                                      style:
                                                                          TextStyle(
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .info,
                                                                      ),
                                                                    ),
                                                                    duration: Duration(
                                                                        milliseconds:
                                                                            4000),
                                                                    backgroundColor:
                                                                        FlutterFlowTheme.of(context)
                                                                            .primary,
                                                                  ),
                                                                );
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }

                                                      safeSetState(() {});
                                                    },
                                                    text: FFLocalizations.of(
                                                            context)
                                                        .getText(
                                                      '5gsud5z1' /* DEVAM ET */,
                                                    ),
                                                    options: FFButtonOptions(
                                                      height: 40.0,
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  45.0,
                                                                  12.0,
                                                                  45.0,
                                                                  12.0),
                                                      iconPadding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondary,
                                                      textStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .titleSmall
                                                              .override(
                                                                font: GoogleFonts
                                                                    .manrope(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .fontStyle,
                                                                ),
                                                                color: Colors
                                                                    .white,
                                                                fontSize: 18.0,
                                                                letterSpacing:
                                                                    1.8,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                fontStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                              ),
                                                      elevation: 5.0,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10.0),
                                                    ),
                                                    showLoadingIndicator: false,
                                                  ),
                                                ),
                                              ]
                                                  .divide(
                                                      SizedBox(height: 20.0))
                                                  .addToEnd(
                                                      SizedBox(height: 80.0)),
                                            ),
                                          ),
                                        ),
                                        SingleChildScrollView(
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(41.0, 32.0,
                                                          41.0, 0.0),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                        child: SvgPicture.asset(
                                                          'assets/images/register-dog-icon.svg',
                                                          width: 26.0,
                                                          height: 38.0,
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                      Flexible(
                                                        child: Text(
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getText(
                                                            'c9dw02ie' /* İnsanların sizi görebilmesi iç... */,
                                                          ),
                                                          textAlign:
                                                              TextAlign.start,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                font: GoogleFonts
                                                                    .manrope(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .primary,
                                                                fontSize: 13.0,
                                                                letterSpacing:
                                                                    0.2,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                fontStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                              ),
                                                        ),
                                                      ),
                                                    ].divide(
                                                        SizedBox(width: 12.0)),
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: Container(
                                                  width: 354.0,
                                                  height: 354.0,
                                                  child: Stack(
                                                    alignment:
                                                        AlignmentDirectional(
                                                            0.0, 0.0),
                                                    children: [
                                                      ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                        child: SvgPicture.asset(
                                                          'assets/images/dots-on-image.svg',
                                                          width:
                                                              MediaQuery.sizeOf(
                                                                          context)
                                                                      .width *
                                                                  1.0,
                                                          height:
                                                              MediaQuery.sizeOf(
                                                                          context)
                                                                      .height *
                                                                  1.0,
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                0.0, 0.0),
                                                        child: ClipOval(
                                                          child: Container(
                                                            width: 211.0,
                                                            height: 211.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryBackground,
                                                              shape: BoxShape
                                                                  .circle,
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondary,
                                                                width: 1.78,
                                                              ),
                                                            ),
                                                            child: Align(
                                                              alignment:
                                                                  AlignmentDirectional(
                                                                      0.0, 0.0),
                                                              child: Stack(
                                                                children: [
                                                                  Opacity(
                                                                    opacity:
                                                                        valueOrDefault<
                                                                            double>(
                                                                      (_model.uploadedLocalFile1.bytes?.isEmpty ?? true)
                                                                          ? 0.0
                                                                          : 1.0,
                                                                      0.0,
                                                                    ),
                                                                    child:
                                                                        ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              100.0),
                                                                      child: Image
                                                                          .memory(
                                                                        _model.uploadedLocalFile1.bytes ??
                                                                            Uint8List.fromList([]),
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            1.0,
                                                                        height: MediaQuery.sizeOf(context).height *
                                                                            1.0,
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Opacity(
                                                                    opacity:
                                                                        valueOrDefault<
                                                                            double>(
                                                                      (_model.uploadedLocalFile1.bytes?.isNotEmpty ?? false)
                                                                          ? 0.0
                                                                          : 1.0,
                                                                      1.0,
                                                                    ),
                                                                    child:
                                                                        Align(
                                                                      alignment:
                                                                          AlignmentDirectional(
                                                                              0.0,
                                                                              0.0),
                                                                      child:
                                                                          FFButtonWidget(
                                                                        onPressed:
                                                                            () async {
                                                                          final selectedMedia =
                                                                              await selectMediaWithSourceBottomSheet(
                                                                            context:
                                                                                context,
                                                                            allowPhoto:
                                                                                true,
                                                                          );
                                                                          if (selectedMedia != null &&
                                                                              selectedMedia.every((m) => validateFileFormat(m.storagePath, context))) {
                                                                            safeSetState(() =>
                                                                                _model.isDataUploading1 = true);
                                                                            var selectedUploadedFiles =
                                                                                <FFUploadedFile>[];

                                                                            try {
                                                                              selectedUploadedFiles = selectedMedia
                                                                                  .map((m) => FFUploadedFile(
                                                                                        name: m.storagePath.split('/').last,
                                                                                        bytes: m.bytes,
                                                                                        height: m.dimensions?.height,
                                                                                        width: m.dimensions?.width,
                                                                                        blurHash: m.blurHash,
                                                                                      ))
                                                                                  .toList();
                                                                            } finally {
                                                                              _model.isDataUploading1 = false;
                                                                            }
                                                                            if (selectedUploadedFiles.length ==
                                                                                selectedMedia.length) {
                                                                              safeSetState(() {
                                                                                _model.uploadedLocalFile1 = selectedUploadedFiles.first;
                                                                              });
                                                                            } else {
                                                                              safeSetState(() {});
                                                                              return;
                                                                            }
                                                                          }
                                                                        },
                                                                        text:
                                                                            '',
                                                                        icon:
                                                                            Icon(
                                                                          Icons
                                                                              .file_upload_outlined,
                                                                          color:
                                                                              FlutterFlowTheme.of(context).primary,
                                                                          size:
                                                                              76.0,
                                                                        ),
                                                                        options:
                                                                            FFButtonOptions(
                                                                          width:
                                                                              MediaQuery.sizeOf(context).width * 1.0,
                                                                          height:
                                                                              MediaQuery.sizeOf(context).height * 1.0,
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              16.0,
                                                                              0.0,
                                                                              16.0,
                                                                              0.0),
                                                                          iconAlignment:
                                                                              IconAlignment.end,
                                                                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              0.0),
                                                                          color:
                                                                              Color(0x03F25822),
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .override(
                                                                                font: GoogleFonts.manrope(
                                                                                  fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                ),
                                                                                color: Colors.white,
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                              ),
                                                                          elevation:
                                                                              0.0,
                                                                          borderRadius:
                                                                              BorderRadius.circular(8.0),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                0.0, 1.0),
                                                        child: Container(
                                                          width:
                                                              MediaQuery.sizeOf(
                                                                          context)
                                                                      .width *
                                                                  1.0,
                                                          height:
                                                              double.infinity,
                                                          constraints:
                                                              BoxConstraints(
                                                            maxHeight: 80.0,
                                                          ),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Color(
                                                                0x04F7DED0),
                                                          ),
                                                          child: Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0.0, 1.0),
                                                            child:
                                                                AnimatedDefaultTextStyle(
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .montaguSlab(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .fontStyle,
                                                                    ),
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .primary,
                                                                    fontSize:
                                                                        30.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                              duration: Duration(
                                                                  milliseconds:
                                                                      600),
                                                              curve:
                                                                  Curves.easeIn,
                                                              child: Text(
                                                                _model
                                                                    .nameInputModel
                                                                    .customInputTextController
                                                                    .text,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Stack(
                                                    children: [
                                                      Opacity(
                                                        opacity: valueOrDefault<
                                                            double>(
                                                          _model.genderSelectDropdownModel
                                                                      .value?.id ==
                                                                  1
                                                              ? 1.0
                                                              : 0.0,
                                                          0.0,
                                                        ),
                                                        child: Icon(
                                                          Icons.male,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondary,
                                                          size: 20.0,
                                                        ),
                                                      ),
                                                      Opacity(
                                                        opacity: valueOrDefault<
                                                            double>(
                                                          _model.genderSelectDropdownModel
                                                                      .value?.id ==
                                                                  1
                                                              ? 0.0
                                                              : 1.0,
                                                          0.0,
                                                        ),
                                                        child: Icon(
                                                          Icons.female_sharp,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondary,
                                                          size: 20.0,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Container(
                                                    width: 1.0,
                                                    height: 18.0,
                                                    decoration: BoxDecoration(
                                                      color: Color(0x7FF37C20),
                                                    ),
                                                  ),
                                                  Text(
                                                    functions.calculateAge(
                                                        _model
                                                            .birthdateInputModel
                                                            .value),
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'jsMath',
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondary,
                                                          fontSize: 20.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                  ),
                                                ].divide(SizedBox(width: 8.0)),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 72.0, 0.0, 0.0),
                                                child: FFButtonWidget(
                                                  onPressed: () async {
                                                    if ((_model
                                                                .uploadedLocalFile1
                                                                .bytes
                                                                ?.isNotEmpty ??
                                                            false)) {
                                                      await _model
                                                          .pageViewController
                                                          ?.nextPage(
                                                        duration: Duration(
                                                            milliseconds: 300),
                                                        curve: Curves.ease,
                                                      );
                                                    } else {
                                                      ScaffoldMessenger.of(
                                                              context)
                                                          .showSnackBar(
                                                        SnackBar(
                                                          content: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getVariableText(
                                                              trText:
                                                                  'Profil fotoğrafı zorunludur..!',
                                                              enText:
                                                                  'Profile Photo Is Required!',
                                                            ),
                                                            style: TextStyle(
                                                              color: Color(
                                                                  0xFFFF0000),
                                                              fontSize: 12.0,
                                                            ),
                                                            textAlign: TextAlign
                                                                .center,
                                                          ),
                                                          duration: Duration(
                                                              milliseconds:
                                                                  4000),
                                                          backgroundColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .info,
                                                        ),
                                                      );
                                                    }
                                                  },
                                                  text: FFLocalizations.of(
                                                          context)
                                                      .getText(
                                                    '6b1a299c' /* DEVAM ET */,
                                                  ),
                                                  options: FFButtonOptions(
                                                    height: 40.0,
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                45.0,
                                                                12.0,
                                                                45.0,
                                                                12.0),
                                                    iconPadding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                0.0, 0.0),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondary,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .titleSmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .manrope(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                          ),
                                                          color: Colors.white,
                                                          fontSize: 18.0,
                                                          letterSpacing: 1.8,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontStyle,
                                                        ),
                                                    elevation: 5.0,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10.0),
                                                  ),
                                                  showLoadingIndicator: false,
                                                ),
                                              ),
                                            ].addToEnd(SizedBox(height: 80.0)),
                                          ),
                                        ),
                                        Form(
                                          key: _model.formKey1,
                                          autovalidateMode:
                                              AutovalidateMode.disabled,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Align(
                                                  alignment:
                                                      AlignmentDirectional(
                                                          0.0, 0.0),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                41.0,
                                                                32.0,
                                                                41.0,
                                                                10.0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                          child:
                                                              SvgPicture.asset(
                                                            'assets/images/register-dog-icon.svg',
                                                            width: 26.0,
                                                            height: 38.0,
                                                            fit: BoxFit.cover,
                                                          ),
                                                        ),
                                                        Flexible(
                                                          child: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              '0hfahpzw' /* Şimdi köpeğinizin sırası. Lütf... */,
                                                            ),
                                                            textAlign:
                                                                TextAlign.start,
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font: GoogleFonts
                                                                      .manrope(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primary,
                                                                  fontSize:
                                                                      13.0,
                                                                  letterSpacing:
                                                                      0.2,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                      ].divide(SizedBox(
                                                          width: 12.0)),
                                                    ),
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model:
                                                      _model.dogNameInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: TextInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Köpeğinizin İsmi',
                                                      enText:
                                                          'Name of Your Dog',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: true,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .dogKindSelectDropdownModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: SelectDropdownWidget(
                                                    labelTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Köpeğinizin Cinsi',
                                                      enText:
                                                          'Breed of Your Dog',
                                                    ),
                                                    dropdownTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Köpeğinizin Cinsini Seçin',
                                                      enText:
                                                          'Select Breed of Your Dog',
                                                    ),
                                                    options:
                                                        FFAppState().DogTypes,
                                                    sheetTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Köpeğinizin Cinsini Seçin',
                                                      enText:
                                                          'Select Kind of Your Dog',
                                                    ),
                                                    absorbing: false,
                                                    isRequired: true,
                                                    onValueChange:
                                                        (value) async {},
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .dogBirthdateInputModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: DateInputWrapperWidget(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText: 'Doğum Tarihi',
                                                      enText: 'Birth Date',
                                                    ),
                                                    isRequired: true,
                                                    isAutoFocus: false,
                                                  ),
                                                ),
                                                wrapWithModel(
                                                  model: _model
                                                      .dogGenderSelectDropdownModel,
                                                  updateCallback: () =>
                                                      safeSetState(() {}),
                                                  child: SelectDropdownWidget(
                                                    labelTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Köpeğinizin Cinsiyeti',
                                                      enText: 'Sex of Your Dog',
                                                    ),
                                                    dropdownTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Köpeğinizin Cinsiyetini Seçin',
                                                      enText:
                                                          'Select Sex of Your Dog',
                                                    ),
                                                    options:
                                                        FFAppState().DogGenders,
                                                    sheetTitle:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getVariableText(
                                                      trText:
                                                          'Köpeğinizin Cinsiyetini Seçin',
                                                      enText:
                                                          'Select Sex of Your Dog',
                                                    ),
                                                    absorbing: false,
                                                    isRequired: true,
                                                    onValueChange:
                                                        (value) async {},
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 26.0, 0.0, 0.0),
                                                  child: FFButtonWidget(
                                                    onPressed: () async {
                                                      if ((_model
                                                                      .dogNameInputModel
                                                                      .customInputTextController
                                                                      .text ==
                                                                  '') ||
                                                          (_model
                                                                  .dogBirthdateInputModel
                                                                  .value ==
                                                              null) ||
                                                          (_model.dogGenderSelectDropdownModel
                                                                  .value ==
                                                              null) ||
                                                          (_model.dogKindSelectDropdownModel
                                                                  .value ==
                                                              null)) {
                                                        ScaffoldMessenger.of(
                                                                context)
                                                            .showSnackBar(
                                                          SnackBar(
                                                            content: Text(
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .getVariableText(
                                                                trText:
                                                                    'Lütfen Zorunlu Alanları Doldurunuz',
                                                                enText:
                                                                    'Please fill the required fields',
                                                              ),
                                                              style: TextStyle(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .info,
                                                              ),
                                                            ),
                                                            duration: Duration(
                                                                milliseconds:
                                                                    4000),
                                                            backgroundColor:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .primary,
                                                          ),
                                                        );
                                                      } else {
                                                        _model.form2Validate =
                                                            true;
                                                        if (_model.formKey1
                                                                    .currentState ==
                                                                null ||
                                                            !_model.formKey1
                                                                .currentState!
                                                                .validate()) {
                                                          safeSetState(() =>
                                                              _model.form2Validate =
                                                                  false);
                                                          return;
                                                        }
                                                        if (_model
                                                            .form2Validate!) {
                                                          await _model
                                                              .pageViewController
                                                              ?.nextPage(
                                                            duration: Duration(
                                                                milliseconds:
                                                                    300),
                                                            curve: Curves.ease,
                                                          );
                                                        }
                                                      }

                                                      safeSetState(() {});
                                                    },
                                                    text: FFLocalizations.of(
                                                            context)
                                                        .getText(
                                                      'tk3h5rh2' /* DEVAM ET */,
                                                    ),
                                                    options: FFButtonOptions(
                                                      height: 40.0,
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  45.0,
                                                                  12.0,
                                                                  45.0,
                                                                  12.0),
                                                      iconPadding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondary,
                                                      textStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .titleSmall
                                                              .override(
                                                                font: GoogleFonts
                                                                    .manrope(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .fontStyle,
                                                                ),
                                                                color: Colors
                                                                    .white,
                                                                fontSize: 18.0,
                                                                letterSpacing:
                                                                    1.8,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                fontStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                              ),
                                                      elevation: 5.0,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10.0),
                                                    ),
                                                    showLoadingIndicator: false,
                                                  ),
                                                ),
                                              ]
                                                  .divide(
                                                      SizedBox(height: 20.0))
                                                  .addToEnd(
                                                      SizedBox(height: 80.0)),
                                            ),
                                          ),
                                        ),
                                        SingleChildScrollView(
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(41.0, 32.0,
                                                          41.0, 0.0),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                        child: SvgPicture.asset(
                                                          'assets/images/register-dog-icon.svg',
                                                          width: 26.0,
                                                          height: 38.0,
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                      Flexible(
                                                        child: Text(
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getText(
                                                            'ij1cyji8' /* Köpeğinizin profil fotoğrafını... */,
                                                          ),
                                                          textAlign:
                                                              TextAlign.start,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                font: GoogleFonts
                                                                    .manrope(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .primary,
                                                                fontSize: 13.0,
                                                                letterSpacing:
                                                                    0.2,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                fontStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                              ),
                                                        ),
                                                      ),
                                                    ].divide(
                                                        SizedBox(width: 12.0)),
                                                  ),
                                                ),
                                              ),
                                              Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: Container(
                                                  width: 354.0,
                                                  height: 354.0,
                                                  child: Stack(
                                                    alignment:
                                                        AlignmentDirectional(
                                                            0.0, 0.0),
                                                    children: [
                                                      ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                        child: SvgPicture.asset(
                                                          'assets/images/dots-on-image.svg',
                                                          width:
                                                              MediaQuery.sizeOf(
                                                                          context)
                                                                      .width *
                                                                  1.0,
                                                          height:
                                                              MediaQuery.sizeOf(
                                                                          context)
                                                                      .height *
                                                                  1.0,
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                0.0, 0.0),
                                                        child: ClipOval(
                                                          child: Container(
                                                            width: 211.0,
                                                            height: 211.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .secondaryBackground,
                                                              shape: BoxShape
                                                                  .circle,
                                                              border:
                                                                  Border.all(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondary,
                                                                width: 1.78,
                                                              ),
                                                            ),
                                                            child: Align(
                                                              alignment:
                                                                  AlignmentDirectional(
                                                                      0.0, 0.0),
                                                              child: Stack(
                                                                children: [
                                                                  Opacity(
                                                                    opacity:
                                                                        valueOrDefault<
                                                                            double>(
                                                                      (_model.uploadedLocalFile2.bytes?.isNotEmpty ?? false)
                                                                          ? 1.0
                                                                          : 0.0,
                                                                      0.0,
                                                                    ),
                                                                    child:
                                                                        ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              100.0),
                                                                      child: Image
                                                                          .memory(
                                                                        _model.uploadedLocalFile2.bytes ??
                                                                            Uint8List.fromList([]),
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            1.0,
                                                                        height: MediaQuery.sizeOf(context).height *
                                                                            1.0,
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Opacity(
                                                                    opacity:
                                                                        valueOrDefault<
                                                                            double>(
                                                                      (_model.uploadedLocalFile2.bytes?.isNotEmpty ?? false)
                                                                          ? 0.0
                                                                          : 1.0,
                                                                      1.0,
                                                                    ),
                                                                    child:
                                                                        FFButtonWidget(
                                                                      onPressed:
                                                                          () async {
                                                                        final selectedMedia =
                                                                            await selectMediaWithSourceBottomSheet(
                                                                          context:
                                                                              context,
                                                                          imageQuality:
                                                                              100,
                                                                          allowPhoto:
                                                                              true,
                                                                        );
                                                                        if (selectedMedia !=
                                                                                null &&
                                                                            selectedMedia.every((m) =>
                                                                                validateFileFormat(m.storagePath, context))) {
                                                                          safeSetState(() =>
                                                                              _model.isDataUploading2 = true);
                                                                          var selectedUploadedFiles =
                                                                              <FFUploadedFile>[];

                                                                          try {
                                                                            selectedUploadedFiles = selectedMedia
                                                                                .map((m) => FFUploadedFile(
                                                                                      name: m.storagePath.split('/').last,
                                                                                      bytes: m.bytes,
                                                                                      height: m.dimensions?.height,
                                                                                      width: m.dimensions?.width,
                                                                                      blurHash: m.blurHash,
                                                                                    ))
                                                                                .toList();
                                                                          } finally {
                                                                            _model.isDataUploading2 =
                                                                                false;
                                                                          }
                                                                          if (selectedUploadedFiles.length ==
                                                                              selectedMedia.length) {
                                                                            safeSetState(() {
                                                                              _model.uploadedLocalFile2 = selectedUploadedFiles.first;
                                                                            });
                                                                          } else {
                                                                            safeSetState(() {});
                                                                            return;
                                                                          }
                                                                        }
                                                                      },
                                                                      text: '',
                                                                      icon:
                                                                          Icon(
                                                                        Icons
                                                                            .file_upload_outlined,
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primary,
                                                                        size:
                                                                            76.0,
                                                                      ),
                                                                      options:
                                                                          FFButtonOptions(
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            1.0,
                                                                        height: MediaQuery.sizeOf(context).height *
                                                                            1.0,
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                        iconAlignment:
                                                                            IconAlignment.end,
                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        color: Color(
                                                                            0x00F25822),
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .titleSmall
                                                                            .override(
                                                                              font: GoogleFonts.manrope(
                                                                                fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                              ),
                                                                              color: Colors.white,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                            ),
                                                                        elevation:
                                                                            0.0,
                                                                        borderRadius:
                                                                            BorderRadius.circular(8.0),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                0.0, 1.0),
                                                        child: Container(
                                                          width:
                                                              MediaQuery.sizeOf(
                                                                          context)
                                                                      .width *
                                                                  1.0,
                                                          height:
                                                              double.infinity,
                                                          constraints:
                                                              BoxConstraints(
                                                            maxHeight: 80.0,
                                                          ),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Color(
                                                                0x04F7DED0),
                                                          ),
                                                          child: Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0.0, 1.0),
                                                            child: Text(
                                                              _model
                                                                  .dogNameInputModel
                                                                  .customInputTextController
                                                                  .text,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .montaguSlab(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .fontStyle,
                                                                    ),
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .primary,
                                                                    fontSize:
                                                                        30.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Builder(
                                                    builder: (context) {
                                                      if (_model
                                                              .dogGenderSelectDropdownModel
                                                              .value
                                                              ?.id ==
                                                          1) {
                                                        return Icon(
                                                          Icons.male,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondary,
                                                          size: 20.0,
                                                        );
                                                      } else {
                                                        return Icon(
                                                          Icons.female_sharp,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondary,
                                                          size: 20.0,
                                                        );
                                                      }
                                                    },
                                                  ),
                                                  Container(
                                                    width: 1.0,
                                                    height: 18.0,
                                                    decoration: BoxDecoration(
                                                      color: Color(0x7FF37C20),
                                                    ),
                                                  ),
                                                  Text(
                                                    functions.calculateAge(_model
                                                        .dogBirthdateInputModel
                                                        .value),
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'jsMath',
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondary,
                                                          fontSize: 20.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                  ),
                                                ].divide(SizedBox(width: 8.0)),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 72.0, 0.0, 0.0),
                                                child: FFButtonWidget(
                                                  onPressed: () async {
                                                    if ((_model
                                                                .uploadedLocalFile2
                                                                .bytes
                                                                ?.isNotEmpty ??
                                                            false)) {
                                                      FFAppState()
                                                              .RegisteringUser =
                                                          UserStruct(
                                                        firstName: _model
                                                            .nameInputModel
                                                            .customInputTextController
                                                            .text,
                                                        lastName: _model
                                                            .surnameInputModel
                                                            .customInputTextController
                                                            .text,
                                                        username: _model
                                                            .usernameWrapperModel
                                                            .customInputTextController
                                                            .text,
                                                        email: _model
                                                            .emailWrapperModel
                                                            .customInputTextController
                                                            .text,
                                                        phoneNumber: _model
                                                            .phoneInputModel
                                                            .customInputTextController
                                                            .text,
                                                        userGender: _model
                                                            .genderSelectDropdownModel
                                                            .value
                                                            ?.id
                                                            .toString(),
                                                        address: _model
                                                            .addressInputModel
                                                            .customInputTextController
                                                            .text,
                                                        city: _model
                                                            .citySelectDropdownModel
                                                            .value,
                                                        country: _model
                                                            .countrySelectDropdownModel
                                                            .value,
                                                        dateBirth: _model
                                                            .birthdateInputModel
                                                            .value,
                                                      );
                                                      FFAppState()
                                                              .RegisteringUserPrimaryDog =
                                                          DogRelationTypeStruct(
                                                        action: 'store',
                                                        key: 'dogs',
                                                        title: _model
                                                            .dogNameInputModel
                                                            .customInputTextController
                                                            .text,
                                                        dogType: _model
                                                            .dogKindSelectDropdownModel
                                                            .value,
                                                        gender: _model
                                                            .dogGenderSelectDropdownModel
                                                            .value
                                                            ?.id,
                                                        birthDate: _model
                                                            .dogBirthdateInputModel
                                                            .value,
                                                      );
                                                      FFAppState()
                                                          .update(() {});
                                                      await showModalBottomSheet(
                                                        isScrollControlled:
                                                            true,
                                                        backgroundColor:
                                                            Colors.transparent,
                                                        enableDrag: false,
                                                        context: context,
                                                        builder: (context) {
                                                          return WebViewAware(
                                                            child:
                                                                GestureDetector(
                                                              onTap: () {
                                                                FocusScope.of(
                                                                        context)
                                                                    .unfocus();
                                                                FocusManager
                                                                    .instance
                                                                    .primaryFocus
                                                                    ?.unfocus();
                                                              },
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    Container(
                                                                  height: MediaQuery.sizeOf(
                                                                              context)
                                                                          .height *
                                                                      1.0,
                                                                  child:
                                                                      RegisterDoneSheetWidget(
                                                                    userAvatar:
                                                                        _model
                                                                            .uploadedLocalFile1,
                                                                    primaryDogAvatar:
                                                                        _model
                                                                            .uploadedLocalFile2,
                                                                    password: _model
                                                                        .passwordInputModel
                                                                        .customInputTextController
                                                                        .text,
                                                                    passwordConfirmation: _model
                                                                        .repeatPasswordInputModel
                                                                        .customInputTextController
                                                                        .text,
                                                                    dogs: _model
                                                                        .dogs,
                                                                    dogAvatars:
                                                                        _model
                                                                            .dogAvatars,
                                                                    onAddDog: (dog,
                                                                        dogAvatar) async {
                                                                      _model.addToDogs(
                                                                          dog);
                                                                      _model.addToDogAvatars(
                                                                          dogAvatar);
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                      ).then((value) =>
                                                          safeSetState(() {}));
                                                    } else {
                                                      ScaffoldMessenger.of(
                                                              context)
                                                          .showSnackBar(
                                                        SnackBar(
                                                          content: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getVariableText(
                                                              trText:
                                                                  'Köpek Profil Resmi Zorunludur',
                                                              enText:
                                                                  'Dog Profile Photo Is Required',
                                                            ),
                                                            style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                          ),
                                                          duration: Duration(
                                                              milliseconds:
                                                                  4000),
                                                          backgroundColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .secondary,
                                                        ),
                                                      );
                                                    }
                                                  },
                                                  text: FFLocalizations.of(
                                                          context)
                                                      .getText(
                                                    't4tawj7h' /* DEVAM ET */,
                                                  ),
                                                  options: FFButtonOptions(
                                                    height: 40.0,
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                45.0,
                                                                12.0,
                                                                45.0,
                                                                12.0),
                                                    iconPadding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                0.0, 0.0),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondary,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .titleSmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .manrope(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                          ),
                                                          color: Colors.white,
                                                          fontSize: 18.0,
                                                          letterSpacing: 1.8,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontStyle,
                                                        ),
                                                    elevation: 5.0,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10.0),
                                                  ),
                                                  showLoadingIndicator: false,
                                                ),
                                              ),
                                            ].addToEnd(SizedBox(height: 80.0)),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 32.0,
                                  decoration: BoxDecoration(),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Expanded(
                                        child: Align(
                                          alignment:
                                              AlignmentDirectional(0.0, 0.0),
                                          child: Container(
                                            decoration: BoxDecoration(),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, -1.0),
                                              child: Container(
                                                width:
                                                    MediaQuery.sizeOf(context)
                                                            .width *
                                                        1.0,
                                                height: 30.0,
                                                child: custom_widgets
                                                    .CustomRegisterIndicator(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  height: 30.0,
                                                  index: _model
                                                      .pageViewCurrentIndex,
                                                  pageCount: 4,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ].divide(SizedBox(height: 12.0)),
                      ),
                    ),
                  ),
                ),
              ),
              if (_model.loading)
                wrapWithModel(
                  model: _model.loadingViewModel,
                  updateCallback: () => safeSetState(() {}),
                  child: LoadingViewWidget(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
