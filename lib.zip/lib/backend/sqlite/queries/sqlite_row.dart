abstract class SqliteRow {
  SqliteRow(this.data);
  late Map<String, dynamic> data;
}
