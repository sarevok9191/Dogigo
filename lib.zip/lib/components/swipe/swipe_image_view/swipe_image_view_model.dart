import '/flutter_flow/flutter_flow_util.dart';
import 'swipe_image_view_widget.dart' show SwipeImageViewWidget;
import 'package:flutter/material.dart';

class SwipeImageViewModel extends FlutterFlowModel<SwipeImageViewWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
