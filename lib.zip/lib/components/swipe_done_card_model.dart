import '/flutter_flow/flutter_flow_util.dart';
import 'swipe_done_card_widget.dart' show SwipeDoneCardWidget;
import 'package:flutter/material.dart';

class SwipeDoneCardModel extends FlutterFlowModel<SwipeDoneCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
