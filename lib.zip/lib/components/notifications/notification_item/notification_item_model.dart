import '/flutter_flow/flutter_flow_util.dart';
import 'notification_item_widget.dart' show NotificationItemWidget;
import 'package:flutter/material.dart';

class NotificationItemModel extends FlutterFlowModel<NotificationItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
