import '/flutter_flow/flutter_flow_util.dart';
import 'fake_snackbar_widget.dart' show FakeSnackbarWidget;
import 'package:flutter/material.dart';

class FakeSnackbarModel extends FlutterFlowModel<FakeSnackbarWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
