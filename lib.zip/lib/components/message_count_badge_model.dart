import '/flutter_flow/flutter_flow_util.dart';
import 'message_count_badge_widget.dart' show MessageCountBadgeWidget;
import 'package:flutter/material.dart';

class MessageCountBadgeModel extends FlutterFlowModel<MessageCountBadgeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
