import '/flutter_flow/flutter_flow_util.dart';
import 'delete_message_modal_widget.dart' show DeleteMessageModalWidget;
import 'package:flutter/material.dart';

class DeleteMessageModalModel
    extends FlutterFlowModel<DeleteMessageModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
