import '/flutter_flow/flutter_flow_util.dart';
import 'web_view_modal_widget.dart' show WebViewModalWidget;
import 'package:flutter/material.dart';

class WebViewModalModel extends FlutterFlowModel<WebViewModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
