import '/flutter_flow/flutter_flow_util.dart';
import 'block_friend_modal_widget.dart' show BlockFriendModalWidget;
import 'package:flutter/material.dart';

class BlockFriendModalModel extends FlutterFlowModel<BlockFriendModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
