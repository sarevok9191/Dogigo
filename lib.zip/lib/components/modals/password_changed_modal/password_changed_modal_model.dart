import '/flutter_flow/flutter_flow_util.dart';
import 'password_changed_modal_widget.dart' show PasswordChangedModalWidget;
import 'package:flutter/material.dart';

class PasswordChangedModalModel
    extends FlutterFlowModel<PasswordChangedModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
