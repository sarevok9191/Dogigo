import '/flutter_flow/flutter_flow_util.dart';
import 'delete_account_modal_widget.dart' show DeleteAccountModalWidget;
import 'package:flutter/material.dart';

class DeleteAccountModalModel
    extends FlutterFlowModel<DeleteAccountModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
