import '/flutter_flow/flutter_flow_util.dart';
import 'add_dog_modal_widget.dart' show AddDogModalWidget;
import 'package:flutter/material.dart';

class AddDogModalModel extends FlutterFlowModel<AddDogModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
