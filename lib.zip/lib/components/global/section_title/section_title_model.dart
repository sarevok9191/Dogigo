import '/flutter_flow/flutter_flow_util.dart';
import 'section_title_widget.dart' show SectionTitleWidget;
import 'package:flutter/material.dart';

class SectionTitleModel extends FlutterFlowModel<SectionTitleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
