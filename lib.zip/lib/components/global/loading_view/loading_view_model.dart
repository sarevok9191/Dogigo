import '/flutter_flow/flutter_flow_util.dart';
import 'loading_view_widget.dart' show LoadingViewWidget;
import 'package:flutter/material.dart';

class LoadingViewModel extends FlutterFlowModel<LoadingViewWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
