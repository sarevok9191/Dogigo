import '/flutter_flow/flutter_flow_util.dart';
import 'date_input_wrapper_widget.dart' show DateInputWrapperWidget;
import 'package:flutter/material.dart';

class DateInputWrapperModel extends FlutterFlowModel<DateInputWrapperWidget> {
  ///  Local state fields for this component.

  DateTime? value;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
