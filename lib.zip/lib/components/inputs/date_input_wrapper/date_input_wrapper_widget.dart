import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'date_input_wrapper_model.dart';
export 'date_input_wrapper_model.dart';

class DateInputWrapperWidget extends StatefulWidget {
  const DateInputWrapperWidget({
    super.key,
    String? labelText,
    bool? isRequired,
    bool? isAutoFocus,
    String? initialValue,
    Color? labelColor,
    this.minDate,
    this.maxDate,
    this.defaultDate,
    Color? pickerTextColor,
    bool? readonly,
  })  : this.labelText = labelText ?? ' ',
        this.isRequired = isRequired ?? true,
        this.isAutoFocus = isAutoFocus ?? false,
        this.initialValue = initialValue ?? '',
        this.labelColor = labelColor ?? const Color(0xFFF25822),
        this.pickerTextColor = pickerTextColor ?? const Color(0xFFF37C20),
        this.readonly = readonly ?? false;

  final String labelText;
  final bool isRequired;
  final bool isAutoFocus;
  final String initialValue;
  final Color labelColor;
  final DateTime? minDate;
  final DateTime? maxDate;
  final DateTime? defaultDate;
  final Color pickerTextColor;
  final bool readonly;

  @override
  State<DateInputWrapperWidget> createState() => _DateInputWrapperWidgetState();
}

class _DateInputWrapperWidgetState extends State<DateInputWrapperWidget> {
  late DateInputWrapperModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DateInputWrapperModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (widget.defaultDate != null) {
        _model.value = widget.defaultDate;
        safeSetState(() {});
      }
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: valueOrDefault<double>(
        widget.readonly ? 0.8 : 1.0,
        1.0,
      ),
      duration: 300.0.ms,
      curve: Curves.easeInOut,
      child: Container(
        decoration: BoxDecoration(),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(19.0, 0.0, 0.0, 0.0),
              child: RichText(
                textScaler: MediaQuery.of(context).textScaler,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: valueOrDefault<String>(
                        widget.labelText,
                        'Name',
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.manrope(
                              fontWeight: FontWeight.w500,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                            color: widget.labelColor,
                            fontSize: 15.0,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.w500,
                            fontStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontStyle,
                          ),
                    ),
                    TextSpan(
                      text: widget.isRequired ? '*' : ' ',
                      style: TextStyle(),
                    )
                  ],
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.manrope(
                          fontWeight: FontWeight.w500,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        color: widget.labelColor,
                        fontSize: 15.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.sizeOf(context).width * 1.0,
              height: 50.0,
              child: custom_widgets.DatePicker(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: 50.0,
                labelText: widget.labelText,
                labelColor: widget.labelColor,
                defaultDate:
                    _model.value != null ? _model.value : widget.defaultDate,
                maxDate: widget.maxDate,
                minDate: widget.minDate,
                pickerTextColor: FlutterFlowTheme.of(context).primary,
                readOnly: widget.readonly,
                onChange: (value) async {
                  _model.value = value;
                  safeSetState(() {});
                },
              ),
            ),
          ].divide(SizedBox(height: 6.0)),
        ),
      ),
    );
  }
}
