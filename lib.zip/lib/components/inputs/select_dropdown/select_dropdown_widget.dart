import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/components/custom_sheets/options_sheet/options_sheet_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'select_dropdown_model.dart';
export 'select_dropdown_model.dart';

class SelectDropdownWidget extends StatefulWidget {
  const SelectDropdownWidget({
    super.key,
    required this.labelTitle,
    required this.dropdownTitle,
    this.options,
    this.onValueChange,
    required this.sheetTitle,
    this.initialValue,
    bool? absorbing,
    bool? isRequired,
    Color? labelColor,
  })  : this.absorbing = absorbing ?? false,
        this.isRequired = isRequired ?? false,
        this.labelColor = labelColor ?? const Color(0xFFF25822);

  final String? labelTitle;
  final String? dropdownTitle;
  final List<SelectableOptionTypeStruct>? options;
  final Future Function(SelectableOptionTypeStruct? value)? onValueChange;
  final String? sheetTitle;
  final SelectableOptionTypeStruct? initialValue;
  final bool absorbing;
  final bool isRequired;
  final Color labelColor;

  @override
  State<SelectDropdownWidget> createState() => _SelectDropdownWidgetState();
}

class _SelectDropdownWidgetState extends State<SelectDropdownWidget> {
  late SelectDropdownModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SelectDropdownModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (widget.initialValue != null) {
        _model.value = widget.options
            ?.where((e) => e.id == widget.initialValue?.id)
            .toList()
            .firstOrNull;
        safeSetState(() {});
      }
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: widget.absorbing == true ? 0.7 : 1.0,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Align(
            alignment: AlignmentDirectional(-1.0, 0.0),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 0.0, 0.0),
              child: RichText(
                textScaler: MediaQuery.of(context).textScaler,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: valueOrDefault<String>(
                        widget.labelTitle,
                        ' Seçim Yapınız',
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.manrope(
                              fontWeight: FontWeight.w500,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                            color: widget.labelColor,
                            fontSize: 15.0,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.w500,
                            fontStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontStyle,
                          ),
                    ),
                    TextSpan(
                      text: widget.isRequired ? '*' : ' ',
                      style: TextStyle(
                        color: valueOrDefault<Color>(
                          widget.labelColor,
                          FlutterFlowTheme.of(context).primary,
                        ),
                      ),
                    )
                  ],
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.manrope(
                          fontWeight: FontWeight.w500,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        color: valueOrDefault<Color>(
                          widget.labelColor,
                          FlutterFlowTheme.of(context).primary,
                        ),
                        fontSize: 15.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
              ),
            ),
          ),
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              if (widget.absorbing == false) {
                await showModalBottomSheet(
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  enableDrag: false,
                  context: context,
                  builder: (context) {
                    return WebViewAware(
                      child: Padding(
                        padding: MediaQuery.viewInsetsOf(context),
                        child: Container(
                          height: MediaQuery.sizeOf(context).height * 1.0,
                          child: OptionsSheetWidget(
                            options: widget.options,
                            title: widget.sheetTitle!,
                            onChange: (value) async {
                              _model.value = widget.options
                                  ?.where((e) => e.id == value.id)
                                  .toList()
                                  .firstOrNull;
                              _model.updatePage(() {});
                            },
                          ),
                        ),
                      ),
                    );
                  },
                ).then((value) => safeSetState(() {}));

                await widget.onValueChange?.call(
                  _model.value,
                );
              }
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15.0),
              child: Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).accent1,
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(30.0, 19.0, 30.0, 19.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _model.value != null
                            ? widget.options!
                                .where((e) => e.id == _model.value?.id)
                                .toList()
                                .firstOrNull!
                                .title
                            : widget.dropdownTitle!,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              font: GoogleFonts.manrope(
                                fontWeight: FontWeight.w500,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontStyle,
                              ),
                              color: FlutterFlowTheme.of(context).primary,
                              fontSize: 15.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w500,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                      ),
                      Icon(
                        Icons.chevron_right_sharp,
                        color: FlutterFlowTheme.of(context).primary,
                        size: 24.0,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ].divide(SizedBox(height: 6.0)),
      ),
    );
  }
}
