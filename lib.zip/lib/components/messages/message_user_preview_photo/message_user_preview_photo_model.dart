import '/flutter_flow/flutter_flow_util.dart';
import 'message_user_preview_photo_widget.dart'
    show MessageUserPreviewPhotoWidget;
import 'package:flutter/material.dart';

class MessageUserPreviewPhotoModel
    extends FlutterFlowModel<MessageUserPreviewPhotoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
