import '/flutter_flow/flutter_flow_util.dart';
import 'conversation_widget.dart' show ConversationWidget;
import 'package:flutter/material.dart';

class ConversationModel extends FlutterFlowModel<ConversationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
