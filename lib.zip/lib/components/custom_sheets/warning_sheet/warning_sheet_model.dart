import '/flutter_flow/flutter_flow_util.dart';
import 'warning_sheet_widget.dart' show WarningSheetWidget;
import 'package:flutter/material.dart';

class WarningSheetModel extends FlutterFlowModel<WarningSheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
