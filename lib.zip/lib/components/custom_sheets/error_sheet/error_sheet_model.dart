import '/flutter_flow/flutter_flow_util.dart';
import 'error_sheet_widget.dart' show ErrorSheetWidget;
import 'package:flutter/material.dart';

class ErrorSheetModel extends FlutterFlowModel<ErrorSheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
