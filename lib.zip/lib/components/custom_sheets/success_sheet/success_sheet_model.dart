import '/flutter_flow/flutter_flow_util.dart';
import 'success_sheet_widget.dart' show SuccessSheetWidget;
import 'package:flutter/material.dart';

class SuccessSheetModel extends FlutterFlowModel<SuccessSheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
